Imports System.Windows.Forms
Imports System.ComponentModel

Public Class HotKeyDialog

#Region " Members "

    Private _hk As Hotkey

#End Region

#Region " Properties "

    <Browsable(False)> _
    Public Property Hotkey() As Hotkey
        Get
            Return Me._hk
        End Get
        Set(ByVal value As Hotkey)
            Me._hk = value
            Me.HotkeyGroupBox.Text = Me._hk.ToString
        End Set
    End Property

#End Region

#Region " Methods "

    Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.FillKeys()
    End Sub

    Private Sub FillKeys()
        Dim fullScreenKeys() As Keys = {Keys.A, Keys.C, Keys.D, Keys.E, Keys.F, Keys.G, Keys.H, Keys.I, _
        Keys.J, Keys.K, Keys.L, Keys.M, Keys.N, Keys.O, Keys.P, Keys.Q, Keys.R, Keys.S, Keys.T, _
        Keys.U, Keys.V, Keys.W, Keys.X, Keys.Y, Keys.Z, Keys.D0, Keys.D1, Keys.D2, Keys.D3, _
        Keys.D4, Keys.D5, Keys.D6, Keys.D7, Keys.D8, Keys.D9, Keys.Delete, Keys.Down, Keys.End, _
        Keys.F1, Keys.F10, Keys.F11, Keys.F13, Keys.F14, Keys.F15, Keys.F16, Keys.F17, _
        Keys.F18, Keys.F19, Keys.F2, Keys.F20, Keys.F21, Keys.F22, Keys.F23, Keys.F24, Keys.F3, _
        Keys.F4, Keys.F5, Keys.F6, Keys.F7, Keys.F8, Keys.F9, Keys.Insert, Keys.Left, Keys.NumLock, _
        Keys.NumPad0, Keys.NumPad1, Keys.NumPad2, Keys.NumPad3, Keys.NumPad4, Keys.NumPad5, _
        Keys.NumPad6, Keys.NumPad7, Keys.NumPad8, Keys.NumPad9, Keys.Oem1, Keys.Oem5, Keys.Oem6, _
        Keys.Oem7, Keys.OemBackslash, Keys.OemClear, Keys.Oemcomma, Keys.OemMinus, Keys.OemOpenBrackets, _
        Keys.OemPeriod, Keys.Oemplus, Keys.OemQuestion, Keys.Oemtilde, Keys.Pause, Keys.Right, _
        Keys.Space, Keys.Tab, Keys.Up, Keys.PrintScreen}
        For Each k As Keys In fullScreenKeys
            Me.KeyComboBox.Items.Add(k)
        Next
    End Sub

    Private Function GetHotkeyData() As Keys
        Dim hotkeyData As Keys = Keys.None
        If Me.CtrlCheckBox.Checked Then
            hotkeyData = hotkeyData Or Keys.Control
        End If
        If Me.AltCheckBox.Checked Then
            hotkeyData = hotkeyData Or Keys.Alt
        End If
        If Me.ShiftCheckBox.Checked Then
            hotkeyData = hotkeyData Or Keys.Shift
        End If
        If Me.KeyComboBox.SelectedIndex <> -1 Then
            hotkeyData = hotkeyData Or CType(Me.KeyComboBox.SelectedItem, Keys)
        End If
        Return hotkeyData
    End Function

    Private Function IsValidEntry() As Boolean
        Dim hk As New Hotkey(Me.Hotkey.Id, Me.GetHotkeyData)
        If Not My.Forms.MenuForm.HotkeyManager.Hotkeys.Contains(hk) Then
            If My.Forms.MenuForm.HotkeyManager.IsAvailable(hk.Data) Then
                Return True
            Else
                Return False
            End If
        Else
            Return True
        End If
    End Function

#End Region

#Region " Events "

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Dim hotkeyData As Keys = Me.GetHotkeyData
        If Me.IsValidEntry Then
            Me._hk.Data = hotkeyData
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Else
            MessageBox.Show("The selected hotkey is unavailable." & _
            Environment.NewLine & "You can run a test before submitting.", _
            "Screen Shot Hotkey", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.Hotkey = Nothing
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ModifierCheckBoxs_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AltCheckBox.CheckedChanged, ShiftCheckBox.CheckedChanged, CtrlCheckBox.CheckedChanged, KeyComboBox.SelectedIndexChanged
        Dim keyData As Keys = Me.GetHotkeyData
        Me.Test_Button.Enabled = (Me.Hotkey.Data <> keyData)
        Me.OK_Button.Enabled = Me.Test_Button.Enabled
        Me.HotkeyGroupBox.Text = Hotkey.ToString(keyData)
    End Sub

    Private Sub HotKeyDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.CtrlCheckBox.Checked = Me.Hotkey.Control
        Me.AltCheckBox.Checked = Me.Hotkey.Alt
        Me.ShiftCheckBox.Checked = Me.Hotkey.Shift
        Me.KeyComboBox.SelectedItem = Me.Hotkey.Key
        Me.HotkeyGroupBox.Text = Me.Hotkey.ToString
    End Sub

    Private Sub Test_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Test_Button.Click
        Dim hk As New Hotkey(Me.Hotkey.Id, Me.GetHotkeyData)
        If Me.IsValidEntry Then
            Me.HotkeyGroupBox.Text = hk.Name & " is Available"
        Else
            Me.HotkeyGroupBox.Text = hk.Name & " is Unavailable"
        End If
    End Sub

#End Region

End Class
