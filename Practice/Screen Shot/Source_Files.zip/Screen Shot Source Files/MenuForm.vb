Imports System.Text
Imports System.Globalization
Imports system.Drawing.Imaging
Imports System.runtime.InteropServices

<Assembly: CLSCompliant(True)> 

#Region " Enumeration "

Public Enum CaptureMode As Integer
    None = 0
    FullScreen = 1
    [Object] = 2
    Rectangle = 3
End Enum

Public Enum SendTo As Integer
    File = 0
    Clipboard = 1
End Enum

Public Enum SaveFile As Integer
    Manual = 0
    Automatic = 1
End Enum

#End Region

Public Class MenuForm

#Region " Members "

    Dim WithEvents wb As New WebBrowser
    Dim WithEvents hkm As HotkeyManager
    Dim _capture As Boolean
    Dim _control As IntPtr = IntPtr.Zero
    Dim _rect As New Rect
    Dim _instantMenu As Boolean
    Dim _cuptureMode As CaptureMode = Global.ScreenShot.CaptureMode.None
    Private Shared fLog As New FileLog(My.Application.Info.Title, _
    My.Computer.FileSystem.SpecialDirectories.Desktop)

#End Region

#Region " Properties "

    Public Shared ReadOnly Property Log() As FileLog
        Get
            Return fLog
        End Get
    End Property

    Public ReadOnly Property HotkeyManager() As HotkeyManager
        Get
            Return Me.hkm
        End Get
    End Property

    Public ReadOnly Property HelpFile() As String
        Get
            Return My.Application.Info.DirectoryPath & "\Screen Shot Help.chm"
        End Get
    End Property

    Public Property InstantMenu() As Boolean
        Get
            Return Me._instantMenu
        End Get
        Set(ByVal value As Boolean)
            If value <> Me._instantMenu Then
                Me._instantMenu = value
                If value Then
                    Me.MenuMotionOn(False, True)
                Else
                    Me.MenuMotionOn(True, False)
                End If
            End If
        End Set
    End Property

    Public Property OffScreen() As Boolean
        Get
            Return (Me.Top = My.Computer.Screen.Bounds.Top - Me.Height)
        End Get
        Set(ByVal value As Boolean)
            If value Then
                Me.Location = New Point(CInt(( _
                My.Computer.Screen.Bounds.Right - Me.Width) / 2), _
                My.Computer.Screen.Bounds.Top - Me.Height)
            Else
                Me.Location = New Point(CInt(( _
                My.Computer.Screen.Bounds.Right - Me.Width) / 2), _
                My.Computer.Screen.Bounds.Top - Me.Height + 1)
            End If
        End Set
    End Property

    Public Property CaptureMode() As Global.ScreenShot.CaptureMode
        Get
            Return Me._cuptureMode
        End Get
        Set(ByVal value As Global.ScreenShot.CaptureMode)
            If Me._cuptureMode <> value Then
                Select Case value
                    Case CaptureMode.FullScreen
                        If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                            Me.MouseHook.RemoveHook()
                        End If
                        If My.Forms.RectangleForm.Visible Then
                            My.Forms.RectangleForm.Close()
                        End If
                        Me.CaptureModeSplitButton.Image = My.Resources.FullScreenImage
                        Me.CaptureModeSplitButton.ToolTipText = String.Empty
                    Case CaptureMode.Object
                        If My.Forms.RectangleForm.Visible Then
                            My.Forms.RectangleForm.Close()
                        End If
                        Me.CaptureModeSplitButton.Image = My.Resources.ObjectOkImage
                        Me.CaptureModeSplitButton.ToolTipText = "Start Object Capture" & "  (" _
                        & Hotkey.ToString(My.Settings.ObjectStartModeHK) & ")"
                    Case CaptureMode.Rectangle
                        If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                            Me.MouseHook.RemoveHook()
                        End If
                        Me.CaptureModeSplitButton.Image = My.Resources.RectangleImage
                        Me.CaptureModeSplitButton.ToolTipText = "Start Rectangle Capture" & "  (" _
                        & Hotkey.ToString(My.Settings.RectangleModeHK) & ")"
                End Select
                Me._cuptureMode = value
                My.Settings.CaptureMode = value
            End If
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub SaveImage(ByVal img As Image, ByVal title As String)
        Dim fileName As String = String.Empty
        Dim myImageFormat As ImageFormat = Nothing
        Dim helper As Boolean
        If My.Settings.FileSaving = SaveFile.Manual Then
            If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                helper = True
                Me.MouseHook.RemoveHook()
            End If
            Me.Activate()
            Me.SaveFileDialog1.Title = "Save As -  " & title
            Me.SaveFileDialog1.OverwritePrompt = False
            Me.SaveFileDialog1.InitialDirectory = My.Settings.DirectoryPath
            Me.SaveFileDialog1.FileName = My.Settings.AutoGeneratedName
            If Me.SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                fileName = Me.SaveFileDialog1.FileName
                Select Case Me.SaveFileDialog1.FilterIndex
                    Case 1
                        myImageFormat = ImageFormat.Png
                    Case 2
                        myImageFormat = ImageFormat.Jpeg
                    Case 3
                        myImageFormat = ImageFormat.Bmp
                    Case 4
                        myImageFormat = ImageFormat.Gif
                    Case 5
                        myImageFormat = ImageFormat.Tiff
                End Select
            End If
            If helper Then
                Me.MouseHook.InstallHook()
            End If
        Else
            myImageFormat = My.Settings.AutoFileFormat
            fileName = MenuForm.GenerateFileName(My.Settings.DirectoryPath, myImageFormat)
        End If
        If img IsNot Nothing AndAlso fileName <> String.Empty AndAlso myImageFormat IsNot Nothing Then
            If myImageFormat IsNot ImageFormat.Jpeg Then
                img.Save(fileName, myImageFormat)
            Else
                Dim codecInfo As ImageCodecInfo = GetEncoderInfo("image/jpeg")
                If codecInfo IsNot Nothing Then
                    img.Save(fileName, codecInfo, MenuForm.GetEncoderParameters(My.Settings.Quality))
                End If
            End If
        End If
    End Sub

    Public Sub MenuMotionOn(ByVal value As Boolean, ByVal enforce As Boolean)
        If enforce Then
            Me.MenuTimer.Enabled = value
        Else
            If value Then
                Dim rect As New Rectangle
                rect = Me.Bounds
                If Not (Control.MousePosition.X > rect.Left _
                AndAlso Control.MousePosition.X < rect.Right _
                AndAlso Control.MousePosition.Y < rect.Bottom) _
                AndAlso Not Me.CaptureModeSplitButton.DropDown.Visible _
                AndAlso Not Me.HelpSplitButton.DropDown.Visible Then
                    Me.MenuTimer.Enabled = True
                End If
            Else
                Me.MenuTimer.Enabled = False
            End If
        End If
    End Sub

    Private Shared Function GenerateFileName(ByVal dir As String, ByVal iFormat As ImageFormat) As String
        Dim count As Integer
        Dim ci As New CultureInfo(String.Empty)
        If My.Computer.FileSystem.DirectoryExists(dir) = False Then
            dir = My.Computer.FileSystem.SpecialDirectories.Desktop
        End If
        Dim sb As New StringBuilder(dir & "\" & My.Settings.AutoGeneratedName)
        sb.Append(".")
        sb.Append(iFormat.ToString.ToLower(ci))
        While My.Computer.FileSystem.FileExists(sb.ToString)
            If count = 0 Then
                count += 1
                sb.Replace(".", count.ToString(ci) & ".")
            Else
                sb.Replace(count.ToString(ci), (count + 1).ToString(ci))
                count += 1
            End If
        End While
        Return sb.ToString
    End Function

    Private Shared Function GetEncoderParameters(ByVal quality As Integer) As EncoderParameters
        'Dim myImageCodecInfo As ImageCodecInfo
        Dim myEncoder As Imaging.Encoder
        Dim myEncoderParameter As EncoderParameter
        Dim myEncoderParameters As EncoderParameters

        ' Create an Encoder object based on the GUID
        ' for the Quality parameter category.
        myEncoder = Imaging.Encoder.Quality

        ' Create an EncoderParameters object.
        ' An EncoderParameters object has an array of EncoderParameter
        ' objects. In this case, there is only one
        ' EncoderParameter object in the array.
        myEncoderParameters = New EncoderParameters(1)
        ' Sets the  quality parameter.
        myEncoderParameter = New EncoderParameter(myEncoder, quality)
        myEncoderParameters.Param(0) = myEncoderParameter
        Return myEncoderParameters
    End Function

    Private Shared Function GetEncoderInfo(ByVal mimeType As String) As ImageCodecInfo
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()
        For Each encoder As ImageCodecInfo In encoders
            If encoder.MimeType = mimeType Then
                Return encoder
            End If
        Next
        Return Nothing
    End Function

    Public Shared Sub GoToTheFolder(ByVal dir As String)
        If My.Computer.FileSystem.DirectoryExists(dir) = False Then
            dir = My.Computer.FileSystem.SpecialDirectories.Desktop
        End If
        Dim p As New System.Diagnostics.Process
        p.StartInfo.FileName = "explorer"
        p.StartInfo.Arguments = dir
        p.Start()
        p.Close()
        p.Dispose()
    End Sub

    Private Shared Sub ClearRectangle(ByVal rect As Rect)
        Dim hwnd As IntPtr = NativeMethods.GetDesktopWindow
        NativeMethods.LockWindowUpdate(hwnd)
        If Not rect.IsEmpty Then
            rect.Inflate(4, 4)
            NativeMethods.InvalidateRect(hwnd, rect, False)
        Else
            NativeMethods.InvalidateRect(hwnd, Nothing, False)
        End If
        NativeMethods.LockWindowUpdate(IntPtr.Zero)
    End Sub

    Private Shared Sub DrawRectangle(ByVal ctr As IntPtr, ByVal rect As Rect)
        If ctr <> IntPtr.Zero AndAlso Not rect.IsEmpty Then
            Dim hDC As IntPtr = NativeMethods.GetDC(IntPtr.Zero)
            If hDC <> IntPtr.Zero Then
                If Not rect.IsEmpty Then
                    Dim g As Drawing.Graphics
                    g = Graphics.FromHdc(hDC)
                    Dim p As New Pen(Color.Red, 2)
                    rect.Inflate(CInt(p.Width), CInt(p.Width))
                    g.DrawRectangle(p, rect.ToRectangle)
                    p.Dispose()
                    g.Dispose()
                End If
            End If
            NativeMethods.ReleaseDC(IntPtr.Zero, hDC)
        End If
    End Sub

    Private Sub FullScreenCapture()
        Me.CaptureModeSplitButton.HideDropDown()
        Me.HelpSplitButton.HideDropDown()
        If Not Me.OffScreen Then
            Me._capture = True
            Me.OffScreen = True
        Else
            Try
                Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
                Dim img As Image
                img = SCapture.FullScreen(My.Settings.IncludeCursor)
                If My.Settings.PlaySound Then
                    Me.PlaySound()
                End If
                If My.Settings.SendTo = SendTo.File Then
                    Me.SaveImage(img, "Full Screen Capture")
                Else
                    My.Computer.Clipboard.SetImage(img)
                End If
            Catch ex As Exception
                Me.MouseHook.RemoveHook()
                Me.TopMost = True
                MessageBox.Show("The capture of the full screen image failed!", _
                "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                MenuForm.Log.WriteException(ex, TraceEventType.Error)
            Finally
                Me.OffScreen = Not Me.InstantMenu
                Me.NotifyIcon1.Icon = My.Resources.AppIcon
            End Try
        End If
    End Sub

    Private Sub ActiveWindowCapture()
        Try
            Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
            Dim img As Image
            img = SCapture.ActiveWindow(My.Settings.IncludeCursor)
            If My.Settings.PlaySound Then
                Me.PlaySound()
            End If
            If My.Settings.SendTo = SendTo.File Then
                Me.SaveImage(img, "Active Window Capture")
            Else
                My.Computer.Clipboard.SetImage(img)
            End If
        Catch ex As Exception
            Me.MouseHook.RemoveHook()
            Me.TopMost = True
            MessageBox.Show("The capture of the active window image failed!", _
            "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MenuForm.Log.WriteException(ex, TraceEventType.Error)
        Finally
            Me.NotifyIcon1.Icon = My.Resources.AppIcon
        End Try
    End Sub

    Private Sub ObjectCapture()
        If Not Me.OffScreen Then
            Me._capture = True
            Me.OffScreen = True
        Else
            Try
                Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
                Dim img As Image
                Dim mp As Point = Control.MousePosition
                img = SCapture.Control(mp, My.Settings.IncludeCursor)
                If My.Settings.PlaySound Then
                    Me.PlaySound()
                End If
                If My.Settings.SendTo = SendTo.File Then
                    Me.SaveImage(img, "Object Capture")
                Else
                    My.Computer.Clipboard.SetImage(img)
                End If
            Catch ex As Exception
                Me.MouseHook.RemoveHook()
                Me.TopMost = True
                MessageBox.Show("The capture of the object image failed!", _
                "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                MenuForm.Log.WriteException(ex, TraceEventType.Error)
            Finally
                Me.OffScreen = Not Me.InstantMenu
                Me.NotifyIcon1.Icon = My.Resources.AppIcon
            End Try
        End If
    End Sub

    Public Sub RectangleCapture()
        If My.Forms.RectangleForm.Opacity <> 1 Then
            My.Forms.RectangleForm.Timer1.Enabled = False
            My.Forms.RectangleForm.TransparencyKey = Color.GhostWhite
            My.Forms.RectangleForm.Opacity = 1
        End If
        If Not Me.OffScreen Then
            Me._capture = True
            Me.OffScreen = True
        Else
            Try
                Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
                Dim img As Image
                img = SCapture.ScreenRectangle(My.Forms.RectangleForm.RectangleToScreen( _
                My.Forms.RectangleForm.Rectangle), My.Settings.IncludeCursor)
                If My.Settings.PlaySound Then
                    Me.PlaySound()
                End If
                If My.Settings.SendTo = SendTo.File Then
                    Me.SaveImage(img, "Rectangle Capture")
                Else
                    My.Computer.Clipboard.SetImage(img)
                End If
            Catch ex As Exception
                Me.MouseHook.RemoveHook()
                Me.TopMost = True
                MessageBox.Show("The capture of the full screen image failed!", _
                "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                MenuForm.Log.WriteException(ex, TraceEventType.Error)
            Finally
                Me.OffScreen = Not Me.InstantMenu
                Me.NotifyIcon1.Icon = My.Resources.AppIcon
            End Try
        End If
        My.Forms.RectangleForm.Timer1.Enabled = True
    End Sub

    Private Sub StartObjectMode()
        If Not My.Forms.AboutBox1.Visible AndAlso Not My.Forms.OptionsDialog.Visible Then
            Me.MouseHook.InstallHook()
        End If
    End Sub

    Public Shared Sub VisitPage(ByVal uriStr As String)
        Dim p As System.Diagnostics.Process = Nothing
        Try
            p = New System.Diagnostics.Process
            p.StartInfo.FileName = uriStr
            p.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MenuForm.Log.WriteException(ex, TraceEventType.Error)
        Finally
            If p IsNot Nothing Then
                p.Close()
                p.Dispose()
            End If
        End Try
    End Sub

    Public Sub CheckForUpdate()
        Dim uri As New Uri(My.Resources.SuportUrl)
        Me.wb.Navigate(uri)
    End Sub

    Private Sub SetHotkeys()
        Dim success As Boolean = True

        If My.Settings.IsFirstRun Then
            My.Settings.FullScreenModeHK = Keys.Control Or Keys.F
            My.Settings.ObjectStartModeHK = Keys.Control Or Keys.O
            My.Settings.ObjectEndModeHK = Keys.Control Or Keys.E
            My.Settings.RectangleModeHK = Keys.Alt Or Keys.R
            My.Settings.ModeCaptureHK = Keys.PrintScreen
            My.Settings.ActiveWindowHK = Keys.Control Or Keys.PrintScreen
            My.Settings.IsFirstRun = False
            My.Settings.Save()
        End If
        If My.Settings.FullScreenModeHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(100, My.Settings.FullScreenModeHK), False) Then
            My.Settings.FullScreenModeHK = Keys.None
            success = False
        End If
        If My.Settings.ObjectStartModeHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(101, My.Settings.ObjectStartModeHK), False) Then
            My.Settings.ObjectStartModeHK = Keys.None
            success = False
        End If
        If My.Settings.ObjectEndModeHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(102, My.Settings.ObjectEndModeHK), False) Then
            My.Settings.ObjectEndModeHK = Keys.None
            success = False
        End If
        If My.Settings.RectangleModeHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(103, My.Settings.RectangleModeHK), False) Then
            My.Settings.RectangleModeHK = Keys.None
            success = False
        End If
        If My.Settings.ModeCaptureHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(104, My.Settings.ModeCaptureHK), False) Then
            My.Settings.ModeCaptureHK = Keys.None
            success = False
        End If
        If My.Settings.ActiveWindowHK = Keys.None Or Not Me.hkm.RegisterHotKey( _
        New Hotkey(105, My.Settings.ActiveWindowHK), False) Then
            My.Settings.ActiveWindowHK = Keys.None
            success = False
        End If
        If Not success Then
            MessageBox.Show("One or more Screen Shot hotkey(s) failed to register." _
            & Environment.NewLine & "You can define Screen Shot hotkeys through the Options window.", _
            "Screen Shot Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub PlaySound()
        My.Computer.Audio.Play(My.Resources.ShotSoundFile, AudioPlayMode.Background)
    End Sub

#End Region

#Region " Events "

    Private Sub MenuForm_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Deactivate
        Me.MenuMotionOn(True, True)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.NotifyIcon1.Text = My.Application.Info.Title _
        & ControlChars.NewLine & String.Format(New CultureInfo(String.Empty), "Version {0}", _
        My.Application.Info.Version.ToString)
        If My.Application.CommandLineArgs.Contains("Icon") Then
            Me.MenuMotionOn(False, True)
            Me.Top = 0
            Me.Activate()
        End If
        Me.Region = Shape.RoundedRegion(Me.Size, 6, Shape.Corner.TopLeft Or Shape.Corner.TopRight)
        If [Enum].IsDefined(GetType(Global.ScreenShot.CaptureMode), My.Settings.CaptureMode) AndAlso My.Settings.CaptureMode <> 0 Then
            Me.CaptureMode = CType(My.Settings.CaptureMode, Global.ScreenShot.CaptureMode)
        Else
            Me.CaptureMode = Global.ScreenShot.CaptureMode.FullScreen
        End If
        If My.Settings.DirectoryPath = String.Empty Then
            My.Settings.DirectoryPath = My.Computer.FileSystem.SpecialDirectories.Desktop
        End If
    End Sub

    Private Sub MenuForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.hkm = New HotkeyManager(Me)
        Me.ClipboardHook.InstallHook(Me)
        Me.SetHotkeys()
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.MouseHook.Dispose()
        Me.ClipboardHook.Dispose()
        Me.SaveFileDialog1.Dispose()
        Me.UpdateTimer.Dispose()
        Me.MenuTimer.Dispose()
        Me.MenuToolStrip.Dispose()
        Me.NotifyIcon1.Dispose()
        Me.ContextMenuStrip1.Dispose()
        Me.wb.Dispose()
        Me.hkm.Dispose()
    End Sub

    Private Sub hkm1_HotkeyPressed(ByVal sender As Object, ByVal e As HotkeyEventArgs) Handles hkm.HotkeyPressed
        If e.Hotkey.Data = My.Settings.ObjectStartModeHK Then
            Me.CaptureMode = ScreenShot.CaptureMode.Object
            Me.StartObjectMode()
        ElseIf e.Hotkey.Data = My.Settings.ObjectEndModeHK Then
            Me.MouseHook.RemoveHook()
        ElseIf e.Hotkey.Data = My.Settings.FullScreenModeHK Then
            Me.CaptureMode = ScreenShot.CaptureMode.FullScreen
        ElseIf e.Hotkey.Data = My.Settings.RectangleModeHK Then
            Me.CaptureMode = ScreenShot.CaptureMode.Rectangle
            If My.Forms.RectangleForm.Visible = False Then
                My.Forms.RectangleForm.Show()
            End If
        ElseIf e.Hotkey.Data = My.Settings.ModeCaptureHK Then
            Select Case Me.CaptureMode
                Case CaptureMode.FullScreen
                    Me.FullScreenCapture()
                Case CaptureMode.Object
                    If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                        Me.ObjectCapture()
                    End If
                Case CaptureMode.Rectangle
                    If My.Forms.RectangleForm.Visible Then
                        Dim frm As ToolBoxForm = CType( _
                        My.Forms.RectangleForm.OwnedForms(0), ToolBoxForm)
                        frm.CaptureRectangleTSB.PerformClick()
                    End If
            End Select
        ElseIf e.Hotkey.Data = My.Settings.ActiveWindowHK Then
            Me.ActiveWindowCapture()
        End If
    End Sub

    Private Sub globalMouse_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MouseHook.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Left Then
            If Not (e.X >= Me.Left AndAlso e.X <= Me.Bounds.Right AndAlso e.Y >= Me.Top AndAlso e.Y <= Me.Bounds.Bottom) Then
                Me.ObjectCapture()
            End If
        End If
    End Sub

    Private Sub globalMouse_MouseDown(ByVal sender As Object, ByVal e As WindowsHook.MouseEventArgs) Handles MouseHook.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            e.Handled = CType(sender, IntPtr) <> Me.MenuToolStrip.Handle
        End If
    End Sub

    Private Sub globalMouse_MouseUp(ByVal sender As Object, ByVal e As WindowsHook.MouseEventArgs) Handles MouseHook.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            e.Handled = CType(sender, IntPtr) <> Me.MenuToolStrip.Handle
        End If
    End Sub

    Private Sub globalMouse_MouseMove(ByVal sender As Object, ByVal e As WindowsHook.MouseEventArgs) Handles MouseHook.MouseMove
        If Me.Handle <> CType(sender, IntPtr) AndAlso Me.MenuToolStrip.Handle <> CType(sender, IntPtr) Then
            If Me._control <> CType(sender, IntPtr) Then
                MenuForm.ClearRectangle(Me._rect)
            End If
            If CType(sender, IntPtr) <> IntPtr.Zero Then
                Me._control = CType(sender, IntPtr)
                NativeMethods.GetWindowRect(Me._control, Me._rect)
                MenuForm.DrawRectangle(CType(sender, IntPtr), Me._rect)
            End If
        End If
    End Sub

    Private Sub globalMouse_StateChanged(ByVal sender As Object, ByVal e As WindowsHook.StateChangedEventArgs) Handles MouseHook.StateChanged
        If e.State = WindowsHook.HookState.Installed Then
            Me.InstantMenu = True
            If Me.OffScreen Then
                Me.OffScreen = False
            End If
            Me.CaptureModeSplitButton.Image = My.Resources.ObjectCancelImage
            Me.CaptureModeSplitButton.ToolTipText = "Cancel the Object Capture" _
            & "  (" & Hotkey.ToString(My.Settings.ObjectEndModeHK) & ")"
        Else
            MenuForm.ClearRectangle(Me._rect)
            Me.InstantMenu = My.Settings.InstantMenu
            Me.CaptureModeSplitButton.Image = My.Resources.ObjectOkImage
            Me.CaptureModeSplitButton.ToolTipText = "Start Object Capture" & "  (" _
            & Hotkey.ToString(My.Settings.ObjectStartModeHK) & ")"
        End If
    End Sub

    Private Sub AboutTSMI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutTSMI.Click
        If Not My.Forms.AboutBox1.Visible Then
            If My.Forms.AboutBox1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                MenuForm.VisitPage(My.Forms.AboutBox1.Link)
            End If
        End If
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitTSMI.Click, ExitButton.Click
        Me.Close()
    End Sub

    Private Sub MenuForm_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseEnter
        If Not Me._capture Then
            Me.Activate()
            Me.MenuMotionOn(False, True)
            Me.Top = 0
        End If
    End Sub

    Private Sub MenuForm_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseLeave
        Me.MenuMotionOn(True, False)
    End Sub

    Private Sub ToolStrip1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuToolStrip.MouseEnter
        If Not Me._capture Then
            Me.Activate()
            Me.Focus()
            Me.MenuMotionOn(False, True)
            Me.Top = 0
            Me.Refresh()
        End If
    End Sub

    Private Sub ToolStrip1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuToolStrip.MouseLeave
        Me.MenuMotionOn(True, False)
    End Sub

    Private Sub NotifyIcon1_BalloonTipClicked(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon1.BalloonTipClicked
        If Me.NotifyIcon1.BalloonTipTitle = "Update Notification" Then
            MenuForm.VisitPage(My.Resources.SuportUrl)
        End If
    End Sub

    Private Sub NotifyIcon1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.MenuMotionOn(False, True)
            Me.Top = 0
            Me.Activate()
        End If
    End Sub

    Private Sub MenuTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuTimer.Tick
        If Me.InstantMenu Then
            If Me.Top > (My.Computer.Screen.Bounds.Top + 1) - Me.Height Then
                Me.Top -= 1
                Me.Refresh()
            Else
                Me.MenuMotionOn(False, True)
                If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                    MenuForm.DrawRectangle(Me._control, Me._rect)
                End If
            End If
        Else
            If Me.Top > My.Computer.Screen.Bounds.Top - Me.Height Then
                Me.Top -= 1
                Me.Refresh()
            Else
                Me.MenuMotionOn(False, True)
                If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                    MenuForm.DrawRectangle(Me._control, Me._rect)
                End If
            End If
        End If
    End Sub

    Private Sub FolderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FolderButton.Click
        Me.MouseHook.RemoveHook()
        If My.Forms.RectangleForm.Visible Then
            My.Forms.RectangleForm.Close()
        End If
        MenuForm.GoToTheFolder(My.Settings.DirectoryPath)
    End Sub

    Private Sub PropertiesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PropertiesButton.Click
        If Not My.Forms.OptionsDialog.Visible Then
            My.Forms.OptionsDialog.ShowDialog()
        End If
    End Sub

    Private Sub HelpHotKeysMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpHotKeysMenuItem.Click, HotKeyMenuItem.Click
        Dim ci As New CultureInfo(String.Empty)
        Dim info As String = String.Empty
        info = "Mode:" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.FullScreenModeHK).ToUpper(ci)
        info &= "  ( full screen )" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.ObjectStartModeHK).ToString.ToUpper(ci)
        info &= "  ( object start )" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.ObjectEndModeHK).ToUpper(ci)
        info &= "  ( object end )" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.RectangleModeHK).ToUpper(ci)
        info &= "  ( rectangle )" & ControlChars.NewLine & ControlChars.NewLine
        info &= "Capture:" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.ModeCaptureHK).ToUpper(ci)
        info &= "  ( current mode )" & ControlChars.NewLine
        info &= Hotkey.ToString(My.Settings.ActiveWindowHK).ToUpper(ci)
        info &= "  ( active window )" & ControlChars.NewLine
        Me.NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
        Me.NotifyIcon1.BalloonTipTitle = "Hotkeys"
        Me.NotifyIcon1.BalloonTipText = info
        Me.NotifyIcon1.ShowBalloonTip(500)
    End Sub

    Private Sub HelpSplitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpSplitButton.Click
        If Me.MouseHook.State = WindowsHook.HookState.Installed Then
            Me.MouseHook.RemoveHook()
        End If
    End Sub

    Private Sub MenuForm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        If Me.OffScreen AndAlso Me._capture Then
            Try
                Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
                Dim img As Image
                Select Case Me.CaptureMode
                    Case CaptureMode.FullScreen
                        img = SCapture.FullScreen(My.Settings.IncludeCursor)
                        If My.Settings.PlaySound Then
                            Me.PlaySound()
                        End If
                        If My.Settings.SendTo = SendTo.File Then
                            Me.SaveImage(img, "Full Screen Capture")
                        Else
                            My.Computer.Clipboard.SetImage(img)
                        End If
                    Case CaptureMode.Object
                        img = SCapture.Control(Control.MousePosition, My.Settings.IncludeCursor)
                        If My.Settings.PlaySound Then
                            Me.PlaySound()
                        End If
                        If My.Settings.SendTo = SendTo.File Then
                            Me.SaveImage(img, "Object Capture")
                        Else
                            My.Computer.Clipboard.SetImage(img)
                        End If
                    Case Global.ScreenShot.CaptureMode.Rectangle
                        img = SCapture.ScreenRectangle(My.Forms.RectangleForm.RectangleToScreen( _
                        My.Forms.RectangleForm.Rectangle), My.Settings.IncludeCursor)
                        If My.Settings.PlaySound Then
                            Me.PlaySound()
                        End If
                        If My.Settings.SendTo = SendTo.File Then
                            Me.SaveImage(img, "Rectangle Capture")
                        Else
                            My.Computer.Clipboard.SetImage(img)
                        End If
                End Select
            Catch ex As Exception
                Me.MouseHook.RemoveHook()
                Me.TopMost = True
                MessageBox.Show("The capture of the image failed!", _
                "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                MenuForm.Log.WriteException(ex, TraceEventType.Error)
            Finally
                Me.OffScreen = Not Me.InstantMenu
                Me.NotifyIcon1.Icon = My.Resources.AppIcon
                Me._capture = False
            End Try
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutMenuItem.Click
        If Not My.Forms.AboutBox1.Visible Then
            If My.Forms.AboutBox1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                MenuForm.VisitPage(My.Forms.AboutBox1.Link)
            End If
        End If
    End Sub

    Private Sub OptionsMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptionsMenuItem.Click
        If Not My.Forms.OptionsDialog.Visible Then
            My.Forms.OptionsDialog.ShowDialog()
        End If
    End Sub

    Private Sub GoImageFolderMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoImageFolderMenuItem.Click
        Me.FolderButton.PerformClick()
    End Sub

    Private Sub ContextMenuStrip1_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening
        If Me.MouseHook.State = WindowsHook.HookState.Installed Then
            Me.MouseHook.RemoveHook()
        End If
    End Sub

    Private Sub CaptureModeSplitButton_ButtonClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CaptureModeSplitButton.ButtonClick
        Select Case Me.CaptureMode
            Case CaptureMode.FullScreen
                Me.FullScreenCapture()
            Case CaptureMode.Object
                If Me.MouseHook.State = WindowsHook.HookState.Installed Then
                    Me.MouseHook.RemoveHook()
                Else
                    Me.StartObjectMode()
                End If
            Case CaptureMode.Rectangle
                If My.Forms.RectangleForm.Visible = False Then
                    My.Forms.RectangleForm.Show()
                End If
        End Select
    End Sub

    Private Sub FullScreenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FullScreenMenuItem.Click
        Me.CaptureMode = CaptureMode.FullScreen
    End Sub

    Private Sub ObjectMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ObjectMenuItem.Click
        Me.CaptureMode = CaptureMode.Object
    End Sub

    Private Sub RectangleMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectangleMenuItem.Click
        Me.CaptureMode = CaptureMode.Rectangle
    End Sub

    Private Sub ClipboardMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClipboardMenuItem.Click
        Try
            Me.NotifyIcon1.Icon = My.Resources.CaptureIcon
            If My.Settings.PlaySound Then
                Me.PlaySound()
            End If
            Me.SaveImage(My.Computer.Clipboard.GetImage, "Clipboard Capture")
        Catch ex As Exception
            Me.MouseHook.RemoveHook()
            MessageBox.Show("The capture of the clipboard image failed!", _
            "Capture Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            MenuForm.Log.WriteException(ex, TraceEventType.Error)
        Finally
            Me.NotifyIcon1.Icon = My.Resources.AppIcon
        End Try
    End Sub

    Private Sub CaptureModeSplitButton_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptureModeSplitButton.DropDownClosed
        Me.MenuMotionOn(True, False)
    End Sub

    Private Sub CaptureModeSplitButton_DropDownOpening(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptureModeSplitButton.DropDownOpening
        If Me.MouseHook.State = WindowsHook.HookState.Installed Then
            Me.MouseHook.RemoveHook()
        End If
        If My.Computer.Clipboard.ContainsImage Then
            Me.ClipboardMenuItem.Enabled = True
        Else
            Me.ClipboardMenuItem.Enabled = False
        End If
        Me.FullScreenMenuItem.ShortcutKeys = My.Settings.FullScreenModeHK
        Me.ObjectMenuItem.ShortcutKeys = My.Settings.ObjectStartModeHK
        Me.RectangleMenuItem.ShortcutKeys = My.Settings.RectangleModeHK
    End Sub

    Private Sub UpdateTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        If My.Settings.CheckForUpdate Then
            Me.CheckForUpdate()
        Else
            Me.UpdateTimer.Enabled = False
        End If
    End Sub

    Private Sub wb_DocumentCompleted(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles wb.DocumentCompleted
        If Me.wb.Document.Body IsNot Nothing Then
            Dim str As String = Me.wb.Document.Body.OuterText
            If str <> String.Empty Then
                Dim searchStr As String = "Current version "
                Dim index As Integer = str.IndexOf(searchStr)
                If index <> -1 Then
                    Me.UpdateTimer.Enabled = False
                    str = str.Substring(index + searchStr.Length, 7)
                    If My.Application.Info.Version.ToString < str Then
                        Dim sb As New StringBuilder
                        sb.Append("An update to Screen Shot is available.")
                        sb.Append(Environment.NewLine)
                        sb.Append("Click me to navigate to the download page.")
                        Me.NotifyIcon1.BalloonTipIcon = ToolTipIcon.Info
                        Me.NotifyIcon1.BalloonTipTitle = "Update Notification"
                        Me.NotifyIcon1.BalloonTipText = sb.ToString
                        Me.NotifyIcon1.ShowBalloonTip(500)
                        Me.NotifyIcon1.Text = My.Application.Info.Title _
                        & String.Format(New Globalization.CultureInfo(String.Empty), " v. {0}", _
                        My.Application.Info.Version.ToString) _
                        & Environment.NewLine & "A Screen Shot update is available!"
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        Dim fileName As String
        Dim extension As String = String.Empty
        Select Case Me.SaveFileDialog1.FilterIndex
            Case 1
                extension = "png"
            Case 2
                extension = "jpeg"
            Case 3
                extension = "bmp"
            Case 4
                extension = "gif"
            Case 5
                extension = "tiff"
        End Select
        fileName = IO.Path.ChangeExtension(Me.SaveFileDialog1.FileName, extension)
        Me.SaveFileDialog1.FileName = fileName
        If IO.File.Exists(fileName) Then
            If MessageBox.Show("File " & fileName & " already exists." & Environment.NewLine & _
            "Do you want to replace it?", Me.SaveFileDialog1.Title, MessageBoxButtons.YesNo, _
            MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No Then
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub ScreenShotHelpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CaptureMenuItem.Click
        Select Case Me.CaptureMode
            Case Global.ScreenShot.CaptureMode.FullScreen
                Help.ShowHelp(Me, Me.HelpFile, HelpNavigator.KeywordIndex, "full screen capture")
            Case Global.ScreenShot.CaptureMode.Object
                Me.MouseHook.RemoveHook()
                Help.ShowHelp(Me, Me.HelpFile, HelpNavigator.KeywordIndex, "object capture")
            Case Global.ScreenShot.CaptureMode.Rectangle
                Help.ShowHelp(My.Forms.RectangleForm, Me.HelpFile, HelpNavigator.KeywordIndex, "rectangle area capture")
        End Select
    End Sub

    Private Sub SearchHelpMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchMenuItem.Click, HelpSearchMenuItem.Click
        Help.ShowHelp(Me, Me.HelpFile, HelpNavigator.Find, String.Empty)
    End Sub

    Private Sub ContentsHelpMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ContentsMenuItem.Click, HelpContentsMenuItem.Click
        Help.ShowHelp(Me, Me.HelpFile, HelpNavigator.TableOfContents)
    End Sub

    Private Sub IndexHelpMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IndexMenuItem.Click, HelpIndexMenuItem.Click
        Help.ShowHelp(Me, Me.HelpFile, HelpNavigator.Index)
    End Sub

    Private Sub ClipboardHook_ClipboardChanged(ByVal sender As Object, ByVal e As WindowsHook.ClipboardEventArgs) Handles ClipboardHook.ClipboardChanged
        Me.ClipboardMenuItem.Enabled = My.Computer.Clipboard.ContainsImage
    End Sub

    Private Sub HelpSplitButton_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles HelpSplitButton.DropDownClosed
        Me.MenuMotionOn(True, False)
    End Sub

    Private Sub CheckForUpdatesMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckForUpdatesMenuItem.Click
        MenuForm.VisitPage(My.Resources.SuportUrl)
    End Sub

#End Region

#Region " Structures "

    <StructLayout(LayoutKind.Sequential)> _
    Friend Structure Rect
        Public Left As Int32
        Public Top As Int32
        Public Right As Int32
        Public Bottom As Int32

        ''' <summary>
        ''' Gets a value indicating whether this ICapture.Rect is empty.
        ''' </summary>
        Public ReadOnly Property IsEmpty() As Boolean
            Get
                Return (Me.Right - Me.Left) < 1 Or (Me.Bottom - Me.Top) < 1
            End Get
        End Property

        ''' <summary>
        ''' Converts the ICapture.Rect object to System.Drawing.Rectangle object.
        ''' </summary>
        Public Function ToRectangle() As Rectangle
            Return New Rectangle(Me.Left, Me.Top, Me.Right - Me.Left, Me.Bottom - Me.Top)
        End Function

        ''' <summary>
        ''' Inflates this ICapture.Rect by the specified amount.
        ''' </summary>
        ''' <param name="width">The amount to inflate this ICapture.Rect horizontally.</param>
        ''' <param name="height">The amount to inflate this ICapture.Rect vertically.</param>
        Public Sub Inflate(ByVal width As Integer, ByVal height As Integer)
            If Not Me.IsEmpty Then
                Me.Left -= width
                Me.Right += width
                Me.Top -= height
                Me.Bottom += height
            End If
        End Sub

        ''' <summary>
        ''' Copies the values of the specified ICapture.Rect to this ICapture.Rect.
        ''' </summary>
        ''' <param name="rect">An ICapture.Rect to be copied from.</param>
        Public Sub Copy(ByVal rect As Rect)
            Me.Left = rect.Left
            Me.Right = rect.Right
            Me.Top = rect.Top
            Me.Bottom = rect.Bottom
        End Sub
    End Structure

#End Region

#Region " NativeMethods "

    Private NotInheritable Class NativeMethods

        Private Sub New()
        End Sub

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function LockWindowUpdate( _
        ByVal hwndLock As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
        End Function

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function InvalidateRect( _
        ByVal hwnd As IntPtr, _
        ByRef lpRect As Rect, _
        <MarshalAs(UnmanagedType.Bool)> _
        ByVal bErase As Boolean) As <MarshalAs(UnmanagedType.Bool)> Boolean
        End Function

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function GetDesktopWindow() As IntPtr
        End Function

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function ReleaseDC( _
        ByVal hWnd As IntPtr, _
        ByVal hdc As IntPtr) As Int32
        End Function

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function GetDC( _
        ByVal hwnd As IntPtr) As IntPtr
        End Function

        <DllImport("user32", SetLastError:=True)> _
        Public Shared Function GetWindowRect( _
        ByVal hWnd As IntPtr, _
        ByRef lpRect As Rect) As <MarshalAs(UnmanagedType.Bool)> Boolean
        End Function

    End Class

#End Region

End Class

