﻿Imports System.Globalization

Public NotInheritable Class AboutBox1

    Private _uri As String

#Region " Properties "

    Public ReadOnly Property Link() As String
        Get
            Return Me._uri
        End Get
    End Property

#End Region

#Region " Events "

    Private Sub AboutBox1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set the title of the form.
        Dim ApplicationTitle As String
        If My.Application.Info.Title <> "" Then
            ApplicationTitle = My.Application.Info.Title
        Else
            ApplicationTitle = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If
        Me.Text = String.Format(CultureInfo.InvariantCulture, "About {0}", ApplicationTitle)
        ' Initialize all of the text displayed on the About Box.
        ' TODO: Customize the application's assembly information in the "Application" pane of the project 
        '    properties dialog (under the "Project" menu).
        Me.LabelProductName.Text = My.Application.Info.ProductName
        Me.LabelVersion.Text = String.Format(CultureInfo.InvariantCulture, "Version {0}", My.Application.Info.Version.ToString)
        Me.LabelCopyright.Text = My.Application.Info.Copyright
        Me.LabelCompanyName.Text = "Author: Arman Ghazanchyan"
        Me.UpdateLinkLabel.Tag = My.Resources.SuportUrl
    End Sub

    Private Sub VisitLinkLabels_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles VisitAMLinkLabel.LinkClicked, ContactLinkLabel.LinkClicked, UpdateLinkLabel.LinkClicked
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Dim lLabel As LinkLabel = DirectCast(sender, LinkLabel)
            Me._uri = CStr(lLabel.Tag)
            Me.DialogResult = Windows.Forms.DialogResult.OK
        End If
    End Sub

#End Region

End Class
