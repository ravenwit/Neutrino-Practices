Imports System.ComponentModel

Public Class HKLabel
    Inherits System.Windows.Forms.Label

    Public Event HotkeyChanged As EventHandler
    Public Event HotkeyIdChanged As EventHandler

    Private _hk As Hotkey

    <Browsable(False)> _
    Public Property Hotkey() As Hotkey
        Get
            Return Me._hk
        End Get
        Set(ByVal value As Hotkey)
            If Me._hk <> value Then
                Me._hk = value
                RaiseEvent HotkeyChanged(Me, New EventArgs)
            End If
            MyBase.Text = Me._hk.ToString
        End Set
    End Property

End Class
