Imports System.Text
Imports System.ComponentModel
Imports System.Configuration.Install
Imports System.Windows.Forms
Imports System.runtime.InteropServices
Imports System.Security.Permissions

Public Class SSInstall

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()
        'Add initialization code after the call to InitializeComponent
    End Sub

    Private _fLog As New FileLog(My.Application.Info.Title, My.Computer.FileSystem.SpecialDirectories.Desktop)

    Private Sub SSInstall_AfterInstall(ByVal sender As Object, ByVal e As System.Configuration.Install.InstallEventArgs) Handles Me.AfterInstall
        Dim p As System.Diagnostics.Process = Nothing
        Try
            p = New System.Diagnostics.Process
            p.StartInfo.FileName = My.Application.Info.DirectoryPath & "\ScreenShot.exe"
            p.StartInfo.Arguments = "Icon"
            p.Start()
            p.Close()
        Catch ex As Exception
            MessageBox.Show("Could not start the Screen Shot for the folwoing reason: " _
            & Environment.NewLine & ex.Message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me._fLog.WriteException(ex, TraceEventType.Critical)
        Finally
            If p IsNot Nothing Then
                p.Dispose()
            End If
        End Try
    End Sub

    Private Sub SSInstall_BeforeUninstall(ByVal sender As Object, ByVal e As System.Configuration.Install.InstallEventArgs) Handles Me.BeforeUninstall
        Dim hWindow As IntPtr = NativeMethods.FindWindow(Nothing, "Screen Shot Menu")
        If hWindow <> IntPtr.Zero Then
            NativeMethods.SendMessage(hWindow, NativeMethods.WM_CLOSE, IntPtr.Zero, IntPtr.Zero)
        End If
        Try
            Dim rk As Microsoft.Win32.RegistryKey
            rk = My.Computer.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Run", True)
            rk.DeleteValue("ScreenShot", False)
        Catch ex As Exception
            MessageBox.Show("Could not remove the application executable path from the registry!" _
            & Environment.NewLine & "You can remove the application executable path from " _
            & Environment.NewLine & "the registry manually by deleting 'ScreenShot' key in" _
            & "'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run' subkey.", _
            My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me._fLog.WriteException(ex, TraceEventType.Error)
        End Try
    End Sub

#Region " NativeMethods "

    <CLSCompliant(True)> _
    Private NotInheritable Class NativeMethods

#Region " Constant "

        Public Const WM_CLOSE As UInt32 = &H10

#End Region

        Private Sub New()
        End Sub

        <DllImport("user32", CharSet:=CharSet.Auto, SetLastError:=True)> _
        Public Shared Function FindWindow(ByVal lpClassName As String, _
        ByVal lpWindowName As String) As IntPtr
        End Function

        <DllImport("user32", CharSet:=CharSet.Auto, SetLastError:=True)> _
        Public Shared Function SendMessage(ByVal hwnd As IntPtr, _
        ByVal wMsg As UInt32, ByVal wParam As IntPtr, _
        ByVal lParam As IntPtr) As IntPtr
        End Function

    End Class

#End Region

End Class
