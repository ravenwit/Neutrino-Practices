Imports System.Drawing.Drawing2D

Public Class RectangleForm

#Region " Members "

    Dim _pt As Point = Nothing
    Dim _tollbarFrm As ToolBoxForm
    Dim _rect As Rectangle

#End Region

#Region " Properties "

    Public Property Rectangle() As Rectangle
        Get
            Return Me._rect
        End Get
        Private Set(ByVal value As Rectangle)
            Me._rect = value
            If Not Me._tollbarFrm Is Nothing Then
                Me._tollbarFrm.DimensionsLabel.Text = CStr( _
                Me._rect.Width) & " x " & CStr( _
                Me._rect.Height) & " " & "pixels"
                Dim rect As Rectangle = Me.RectangleToScreen(Me._rect)
                Dim sRectangle As Rectangle = SystemInformation.VirtualScreen
                Me._tollbarFrm.LeftUpDown.Value = rect.Left
                Me._tollbarFrm.RightUpDown.Value = sRectangle.Width - rect.Right
                Me._tollbarFrm.TopUpDown.Value = rect.Top
                Me._tollbarFrm.BottomUpDown.Value = sRectangle.Height - rect.Bottom
            End If
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub SetMaxMinValues()
        'Max rectangle form width = Screen.PrimaryScreen.Bounds.Width + 12
        'Max rectangle form height = Screen.PrimaryScreen.Bounds.Height + 12
        'The capture rectangle is smaller 14 pixel from each side of the rectangle form.
        If Me._tollbarFrm IsNot Nothing Then
            Dim sRectangle As Rectangle = SystemInformation.VirtualScreen
            Me._tollbarFrm.LeftUpDown.Maximum = Me.Right - 14
            Me._tollbarFrm.LeftUpDown.Minimum = Me.Right + 2 - sRectangle.Width
            Me._tollbarFrm.RightUpDown.Maximum = sRectangle.Width - Me.Left - 14
            Me._tollbarFrm.RightUpDown.Minimum = sRectangle.Width - (Me.Left + sRectangle.Width - 2)
            Me._tollbarFrm.TopUpDown.Maximum = Me.Bottom - 14
            Me._tollbarFrm.TopUpDown.Minimum = Me.Bottom + 2 - sRectangle.Height
            Me._tollbarFrm.BottomUpDown.Maximum = sRectangle.Height - Me.Top - 14
            Me._tollbarFrm.BottomUpDown.Minimum = sRectangle.Height - (Me.Top + sRectangle.Height - 2)
        End If
    End Sub

#End Region

#Region " Events "

    Private Sub QuitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuitMenuItem.Click
        Me.Close()
    End Sub

    Private Sub RectangleForm_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        My.Forms.MenuForm.CaptureModeSplitButton.Enabled = True
    End Sub

    Private Sub Form2_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MouseEnter
        Me.Focus()
    End Sub

    Private Sub RectangleForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Rectangle = New Rectangle(10, 10, Me.Width - 28, Me.Height - 28)
        Me.Timer1.Enabled = True
        Me._tollbarFrm = New ToolBoxForm
        Me._tollbarFrm.Left = Screen.PrimaryScreen.WorkingArea.Width - Me._tollbarFrm.Width
        Me._tollbarFrm.Top = 120
        Me._tollbarFrm.Owner = Me
        Me._tollbarFrm.Show()
        My.Forms.MenuForm.CaptureModeSplitButton.Enabled = False
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim rect As Rectangle = Me.Rectangle
        rect.Inflate(CInt(My.Settings.PenWidth), CInt(My.Settings.PenWidth))
        If Me.RectangleToScreen(rect).Contains(Control.MousePosition) Then
            Me.Opacity = 0.5
            Me.TransparencyKey = Color.Transparent
        Else
            Me.TransparencyKey = Color.GhostWhite
            Me.Opacity = 1
        End If
    End Sub

    Private Sub RectangleForm_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        Me.Rectangle = New Rectangle(10, 10, Me.Width - 28, Me.Height - 28)
        Dim rect As Rectangle = Me.Rectangle
        Dim p1 As New Pen(My.Settings.PenColor, My.Settings.PenWidth)
        p1.DashStyle = My.Settings.DashStyle
        Select Case My.Settings.PenWidth
            Case 1
                rect.X -= 1
                rect.Y -= 1
                rect.Width += 1
                rect.Height += 1
            Case 2
                rect.X -= 1
                rect.Y -= 1
                rect.Width = CInt(rect.Width + My.Settings.PenWidth)
                rect.Height = CInt(rect.Height + My.Settings.PenWidth)
            Case 3
                rect.X -= 2
                rect.Y -= 2
                rect.Width = CInt(rect.Width + My.Settings.PenWidth)
                rect.Height = CInt(rect.Height + My.Settings.PenWidth)
        End Select
        e.Graphics.DrawRectangle(p1, rect)
        p1.Dispose()
        Me.MinimumSize = New Size(28, 28)
        If Me._tollbarFrm IsNot Nothing Then
            If Me.Rectangle.Width > 0 AndAlso Me.Rectangle.Height > 0 Then
                Me._tollbarFrm.CaptureRectangleTSB.Enabled = True
            Else
                Me._tollbarFrm.CaptureRectangleTSB.Enabled = False
            End If
        End If
    End Sub

    Private Sub RectangleForm_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me._pt <> Nothing Then
            Me.Left += e.X - Me._pt.X
            Me.Top += e.Y - Me._pt.Y
        End If
    End Sub

    Private Sub RectangleForm_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        Me._pt = e.Location
    End Sub

    Private Sub RectangleForm_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
        Me._pt = Nothing
    End Sub

    Private Sub RectangleForm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Me.SetMaxMinValues()
        Me.Rectangle = New Rectangle(10, 10, Me.Width - 28, Me.Height - 28)
    End Sub

    Private Sub GoToImageFolderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoToImageFolderToolStripMenuItem.Click
        MenuForm.GoToTheFolder(My.Settings.DirectoryPath)
        Me.Close()
    End Sub

    Private Sub RectangleForm_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDoubleClick
        Me._tollbarFrm.CaptureRectangleTSB.PerformClick()
    End Sub

    Private Sub RectangleForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Me.SetMaxMinValues()
    End Sub

#End Region

End Class