Public Class ToolBoxForm

#Region " Members "

    Dim _rectangleFrm As RectangleForm

#End Region

#Region " Events "

    Private Sub CaptureRectangleTSB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CaptureRectangleTSB.Click
        My.Forms.MenuForm.RectangleCapture()
    End Sub

    Private Sub ToolStrip1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ToolStrip1.MouseEnter
        Me.Focus()
    End Sub

    Private Sub Form3_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        My.Settings.Save()
    End Sub

    Private Sub ToolBarForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            e.Cancel = True
            Me._rectangleFrm.Close()
        End If
    End Sub

    Private Sub ToolBarForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.RightUpDown.Maximum = Decimal.MaxValue
        Me.RightUpDown.Minimum = Decimal.MinValue
        Me.LeftUpDown.Maximum = Decimal.MaxValue
        Me.LeftUpDown.Minimum = Decimal.MinValue
        Me.BottomUpDown.Maximum = Decimal.MaxValue
        Me.BottomUpDown.Minimum = Decimal.MinValue
        Me.TopUpDown.Maximum = Decimal.MaxValue
        Me.TopUpDown.Minimum = Decimal.MinValue
        Me._rectangleFrm = CType(Me.Owner, RectangleForm)
    End Sub

    Private Sub GoToImageFolderTSB_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.PenWidthTSDDB.Text = My.Settings.PenWidth & " pt"
        Me.PenWidthTSDDB.ToolTipText = "Line Width (" & Me.PenWidthTSDDB.Text & ")"
    End Sub

    Private Sub GoToImageFolderTSB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoToImageFolderTSB.Click
        MenuForm.GoToTheFolder(My.Settings.DirectoryPath)
        Me._rectangleFrm.Close()
    End Sub

    Private Sub SolidToolStripMenuItem_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles SolidToolStripMenuItem.Paint
        Dim p1 As New Pen(Color.Black, 1)
        p1.DashStyle = Drawing2D.DashStyle.Solid
        e.Graphics.DrawLine(p1, 5, CInt(Me.SolidToolStripMenuItem.Height / 2) _
        , 20, CInt(Me.SolidToolStripMenuItem.Height / 2))
        p1.Dispose()
    End Sub

    Private Sub DotToolStripMenuItem_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles DotToolStripMenuItem.Paint
        Dim p1 As New Pen(Color.Black, 2)
        p1.DashStyle = Drawing2D.DashStyle.Dot
        e.Graphics.DrawLine(p1, 5, CInt(Me.DotToolStripMenuItem.Height / 2) _
        , 20, CInt(Me.DotToolStripMenuItem.Height / 2))
        p1.Dispose()
    End Sub

    Private Sub DashToolStripMenuItem_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles DashToolStripMenuItem.Paint
        Dim p1 As New Pen(Color.Black, 2)
        p1.DashStyle = Drawing2D.DashStyle.Dash
        e.Graphics.DrawLine(p1, 5, CInt(Me.DashToolStripMenuItem.Height / 2) _
        , 20, CInt(Me.DashToolStripMenuItem.Height / 2))
        p1.Dispose()
    End Sub

    Private Sub PenStyleTSDDB_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PenStyleTSDDB.Paint
        Dim p1 As New Pen(Color.Black, 2)
        p1.DashStyle = My.Settings.DashStyle
        e.Graphics.DrawLine(p1, 5, CInt(Me.PenStyleTSDDB.Height / 2) _
        , 20, CInt(Me.PenStyleTSDDB.Height / 2))
        p1.Dispose()
        Me.PenStyleTSDDB.ToolTipText = "Line Style (" & _
        My.Settings.DashStyle.ToString & ")"
    End Sub

    Private Sub DashToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashToolStripMenuItem.Click
        My.Settings.DashStyle = Drawing2D.DashStyle.Dash
        Me.PenStyleTSDDB.Invalidate()
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub DotToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DotToolStripMenuItem.Click
        My.Settings.DashStyle = Drawing2D.DashStyle.Dot
        Me.PenStyleTSDDB.Invalidate()
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub SolidToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SolidToolStripMenuItem.Click
        My.Settings.DashStyle = Drawing2D.DashStyle.Solid
        Me.PenStyleTSDDB.Invalidate()
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub PenColorTSB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenColorTSB.Click
        Me.ColorDialog1.Color = My.Settings.PenColor
        If Me.ColorDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            My.Settings.PenColor = Me.ColorDialog1.Color
            Me._rectangleFrm.Invalidate()
        End If
    End Sub

    Private Sub PenColorTSB_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PenColorTSB.Paint
        Dim br1 As New SolidBrush(My.Settings.PenColor)
        e.Graphics.FillRectangle(br1, 5, 5, CInt(Me.PenColorTSB.Width - 10), CInt(Me.PenColorTSB.Height - 10))
        br1.Dispose()
        Me.PenColorTSB.ToolTipText = "Line Color (" & My.Settings.PenColor.Name & ")"
    End Sub

    Private Sub Pt1ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pt1ToolStripMenuItem.Click
        My.Settings.PenWidth = 1
        Me.PenWidthTSDDB.Text = 1 & " pt"
        Me.PenWidthTSDDB.ToolTipText = "Line Width (" & Me.PenWidthTSDDB.Text & ")"
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub Pt2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pt2ToolStripMenuItem.Click
        My.Settings.PenWidth = 2
        Me.PenWidthTSDDB.Text = 2 & " pt"
        Me.PenWidthTSDDB.ToolTipText = "Line Width (" & Me.PenWidthTSDDB.Text & ")"
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub Pt3ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pt3ToolStripMenuItem.Click
        My.Settings.PenWidth = 3
        Me.PenWidthTSDDB.Text = 3 & " pt"
        Me.PenWidthTSDDB.ToolTipText = "Line Width (" & Me.PenWidthTSDDB.Text & ")"
        Me._rectangleFrm.Invalidate()
    End Sub

    Private Sub LeftUpDown_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LeftUpDown.ValueChanged
        Dim rect As New Rectangle( _
        CInt(Me.LeftUpDown.Value - 14), _
        Me._rectangleFrm.Top, _
        Me._rectangleFrm.Right - CInt(Me.LeftUpDown.Value - 14), _
        Me._rectangleFrm.Height)
        Me._rectangleFrm.Bounds = rect
    End Sub

    Private Sub RightUpDown_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightUpDown.ValueChanged
        Dim sRectangle As Rectangle = SystemInformation.VirtualScreen
        Dim rect As New Rectangle( _
        Me._rectangleFrm.Left, _
        Me._rectangleFrm.Top, _
        sRectangle.Width - CInt(Me.RightUpDown.Value - 14) - Me._rectangleFrm.Left, _
        Me._rectangleFrm.Height)
        Me._rectangleFrm.Bounds = rect
    End Sub

    Private Sub TopUpDown_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TopUpDown.ValueChanged
        Dim rect As New Rectangle( _
        Me._rectangleFrm.Left, _
        CInt(Me.TopUpDown.Value - 14), _
        Me._rectangleFrm.Width, _
        Me._rectangleFrm.Bottom - CInt(Me.TopUpDown.Value - 14))
        Me._rectangleFrm.Bounds = rect
    End Sub

    Private Sub BottomUpDown_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BottomUpDown.ValueChanged
        Dim sRectangle As Rectangle = SystemInformation.VirtualScreen
        Dim rect As New Rectangle( _
        Me._rectangleFrm.Left, _
        Me._rectangleFrm.Top, _
        Me._rectangleFrm.Width, _
        sRectangle.Height - CInt(Me.BottomUpDown.Value - 14) - Me._rectangleFrm.Top)
        Me._rectangleFrm.Bounds = rect
    End Sub

#End Region

End Class