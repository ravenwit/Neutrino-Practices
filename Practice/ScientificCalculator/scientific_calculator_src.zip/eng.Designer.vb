<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class eng
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.milli = New System.Windows.Forms.Button
        Me.n = New System.Windows.Forms.Button
        Me.G = New System.Windows.Forms.Button
        Me.� = New System.Windows.Forms.Button
        Me.T = New System.Windows.Forms.Button
        Me.k = New System.Windows.Forms.Button
        Me.f = New System.Windows.Forms.Button
        Me.p = New System.Windows.Forms.Button
        Me.M = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'milli
        '
        Me.milli.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.milli.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.milli.Location = New System.Drawing.Point(46, 46)
        Me.milli.Name = "milli"
        Me.milli.Size = New System.Drawing.Size(28, 28)
        Me.milli.TabIndex = 17
        Me.milli.Text = "m"
        Me.milli.UseVisualStyleBackColor = True
        '
        'n
        '
        Me.n.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.n.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.n.Location = New System.Drawing.Point(80, 80)
        Me.n.Name = "n"
        Me.n.Size = New System.Drawing.Size(28, 28)
        Me.n.TabIndex = 16
        Me.n.Text = "n"
        Me.n.UseVisualStyleBackColor = True
        '
        'G
        '
        Me.G.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.G.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.G.Location = New System.Drawing.Point(46, 12)
        Me.G.Name = "G"
        Me.G.Size = New System.Drawing.Size(28, 28)
        Me.G.TabIndex = 15
        Me.G.Text = "G"
        Me.G.UseVisualStyleBackColor = True
        '
        '�
        '
        Me.�.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.�.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.�.Location = New System.Drawing.Point(12, 46)
        Me.�.Name = "�"
        Me.�.Size = New System.Drawing.Size(28, 28)
        Me.�.TabIndex = 14
        Me.�.Text = "�"
        Me.�.UseVisualStyleBackColor = True
        '
        'T
        '
        Me.T.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.T.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.T.Location = New System.Drawing.Point(80, 12)
        Me.T.Name = "T"
        Me.T.Size = New System.Drawing.Size(28, 28)
        Me.T.TabIndex = 13
        Me.T.Text = "T"
        Me.T.UseVisualStyleBackColor = True
        '
        'k
        '
        Me.k.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.k.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.k.Location = New System.Drawing.Point(80, 46)
        Me.k.Name = "k"
        Me.k.Size = New System.Drawing.Size(28, 28)
        Me.k.TabIndex = 12
        Me.k.Text = "k"
        Me.k.UseVisualStyleBackColor = True
        '
        'f
        '
        Me.f.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.f.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.f.Location = New System.Drawing.Point(12, 80)
        Me.f.Name = "f"
        Me.f.Size = New System.Drawing.Size(28, 28)
        Me.f.TabIndex = 11
        Me.f.Text = "f"
        Me.f.UseVisualStyleBackColor = True
        '
        'p
        '
        Me.p.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.p.Location = New System.Drawing.Point(46, 80)
        Me.p.Name = "p"
        Me.p.Size = New System.Drawing.Size(28, 28)
        Me.p.TabIndex = 10
        Me.p.Text = "p"
        Me.p.UseVisualStyleBackColor = True
        '
        'M
        '
        Me.M.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.M.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.M.Location = New System.Drawing.Point(12, 12)
        Me.M.Name = "M"
        Me.M.Size = New System.Drawing.Size(28, 28)
        Me.M.TabIndex = 9
        Me.M.Text = "M"
        Me.M.UseVisualStyleBackColor = True
        '
        'eng
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(118, 118)
        Me.ControlBox = False
        Me.Controls.Add(Me.milli)
        Me.Controls.Add(Me.n)
        Me.Controls.Add(Me.G)
        Me.Controls.Add(Me.�)
        Me.Controls.Add(Me.T)
        Me.Controls.Add(Me.k)
        Me.Controls.Add(Me.f)
        Me.Controls.Add(Me.p)
        Me.Controls.Add(Me.M)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "eng"
        Me.ShowInTaskbar = False
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents milli As System.Windows.Forms.Button
    Friend WithEvents n As System.Windows.Forms.Button
    Friend WithEvents G As System.Windows.Forms.Button
    Friend WithEvents � As System.Windows.Forms.Button
    Friend WithEvents T As System.Windows.Forms.Button
    Friend WithEvents k As System.Windows.Forms.Button
    Friend WithEvents f As System.Windows.Forms.Button
    Friend WithEvents p As System.Windows.Forms.Button
    Friend WithEvents M As System.Windows.Forms.Button
End Class
