Module Math
    Function fract(ByVal val As Double, ByRef a As Integer, ByVal b As Integer, ByVal c As Integer)
        a = System.Math.Truncate(val)
        val = val - a
        val = System.Math.Abs(val)
        Return 0
    End Function
    Function pi1() As Double
        Dim v1, v2 As Double
        Dim m, s As Long
        v1 = 4
        s = -1
        m = 3
        v2 = 4 - 4 / 3
        While Not v2 - v1 = 0
            v1 = v2
            m = m + 2
            s = s * -1
            v2 = v2 + s * 4 / m
        End While
        Return v2
    End Function
    Function pi2() As Double
        Dim r As Double
        r = 4 * (44 * System.Math.Atan(1 / 57) + 7 * System.Math.Atan(1 / 239) - 12 * System.Math.Atan(1 / 682) + 24 * System.Math.Atan(1 / 12943))
        Return r
    End Function
    Function pi3() As Double
        Dim r1, r2 As Double
        Dim k As Long = 2
        r1 = 4 - 2 / 4 - 1 / 5 - 1 / 6
        r2 = r1 + 53 / 6552
        While Not r2 - r1 = 0
            r1 = r2
            r2 = r2 + (4 / (8 * k + 1) - 2 / (8 * k + 4) - 1 / (8 * k + 5) - 1 / (8 * k + 6)) / System.Math.Pow(16, k)
            k = k + 1
        End While
        r2 = r2
        Return r2
    End Function
    Function pi4() As Double
        Dim r1, r2 As Double
        Dim m As Integer = 3
        r1 = 1
        r2 = 1 + 1 / 16
        While Not r2 - r1 = 0
            r1 = r2
            r2 = r2 + 1 / System.Math.Pow(m, 4)
            m = m + 1
        End While
        r2 = r2 * 90
        r2 = System.Math.Pow(r2, 1 / 4)
        Return r2
    End Function
    Function pi5() As Double
        Dim r As Double
        r = System.Math.Log(System.Math.Pow(640320, 3) + 744) / System.Math.Sqrt(163)
        Return r
    End Function
    Function pi6() As Double
        Dim r1, r2 As Double
        Dim m As Integer = 2
        r1 = 13591409 / System.Math.Pow(640320, 3 / 2)
        r2 = r1 - 720.0 * (13591409 + 545140134) / (6 * System.Math.Pow(640320, 3 + 3 / 2))
        While Not r2 - r1 = 0
            r1 = r2
            r2 = r2 + System.Math.Pow(-1, m) * fact(6 * m) * (13591409 + 545140134 * m) / (fact(3 * m) * System.Math.Pow(fact(m), 3) * System.Math.Pow(640320, 3 * m + 3 / 2))
            m = m + 1
        End While
        r2 = 1 / r2
        r2 = r2 / 12
        Return r2
    End Function
    Function pi7() As Double
        Dim r1, r2 As Double
        Dim m As Integer = 2
        r1 = 1103
        r2 = r1 + 24 * (1103 + 26390) / System.Math.Pow(396, 4)
        While Not r2 - r1 = 0
            r1 = r2
            r2 = r2 + fact(4 * m) * (1103 + 26390 * m) / (System.Math.Pow(fact(m), 4) * System.Math.Pow(396, 4 * m))
            m = m + 1
        End While
        r2 = r2 * 2 * System.Math.Sqrt(2) / 9801
        r2 = 1 / r2
        Return r2
    End Function
    Function fact(ByVal x As Double) As Double
        Dim xi As Integer
        xi = System.Math.Truncate(x)
        If (Not x = xi) Or x < 0 Then
            Dim r As Double
            r = (1 / 0) / (1 / 0)
            Return r
        End If
        If x < 2 Then
            Return 1
        End If
        Return x * fact(x - 1)
    End Function
    Function permutaion(ByVal n As Double, ByVal r As Double) As Double
        Return fact(n) / fact(n - r)
    End Function
    Function combination(ByVal n As Double, ByVal r As Double) As Double
        Return fact(n) / (fact(n - r) * fact(r))
    End Function
    Function gcd(ByVal m As Double, ByVal n As ULong) As ULong
        If n = 0 Then
            Return m
        End If
        Return gcd(n, m Mod n)
    End Function
    Function lcm(ByVal m As ULong, ByVal n As ULong) As ULong
        Return m * (n / gcd(m, n))
    End Function
    Function sin(ByVal x As Number) As Number
        Dim r As Number = New Number
        x.rval = x.rval Mod (2 * System.Math.PI)
        r.rval = System.Math.Sin(x.rval) * System.Math.Cosh(x.ival)
        r.ival = System.Math.Cos(x.rval) * System.Math.Sinh(x.ival)
        r.modulus = Math.sqrt(r.rval ^ 2 + r.ival ^ 2)
        r.findamp()
        Return r
    End Function
    Function cos(ByVal x As Number) As Number
        Dim r As Number = New Number
        x.rval = x.rval Mod (2 * System.Math.PI)
        r.rval = System.Math.Cos(x.rval) * System.Math.Cosh(x.ival)
        r.ival = -System.Math.Sin(x.rval) * System.Math.Sinh(x.ival)
        r.modulus = Math.sqrt(r.rval ^ 2 + r.ival ^ 2)
        r.findamp()
        Return r
    End Function
    Function tan(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = sin(x) / cos(x)
        Return r
    End Function
    Function log(ByVal x As Number) As Number
        Dim r As Number = New Number
        r.rval = System.Math.Log(Math.sqrt(x.rval ^ 2 + x.ival ^ 2))
        r.ival = x.amplitude
        r.modulus = Math.sqrt(r.rval ^ 2 + r.ival ^ 2)
        r.findamp()
        Return r
    End Function
    Function log(ByVal x As realnum) As realnum
        Dim r As realnum = New realnum(x)
        r.log()
        Return r
    End Function
    Function asin(ByVal x As Number) As Number
        Dim r As Number
        If x.real Then
            r = New Number(System.Math.Asin(x.rval))
        Else
            r = New Number(0 / 0)
        End If
        Return r
    End Function
    Function acos(ByVal x As Number) As Number
        Dim r As Number
        If x.real Then
            r = New Number(System.Math.Acos(x.rval))
        Else
            r = New Number(0 / 0)
        End If
        Return r
    End Function
    Function atan(ByVal x As Number) As Number
        Dim r As Number = New Number
        Dim t As Number = New Number(1 - x.rval ^ 2 - x.ival ^ 2)
        Dim xr As Number = New Number(x.rval)
        t = t + Number.i * (2 * xr)
        r.rval = 0.5 * t.amplitude
        r.ival = 0.5 * atanh(2 * r.ival / (1 + x.rval ^ 2 + x.ival ^ 2))
        r.modulus = Math.sqrt(r.rval ^ 2 + r.ival ^ 2)
        r.findamp()
        Return r
    End Function
    Function sqrt(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = x ^ 0.5
        Return r
    End Function
    Function sqrt(ByVal x As realnum) As realnum
        Dim r As realnum = New realnum
        r = x ^ 0.5
        Return r
    End Function
    Function sinh(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = (sin(Number.i * x)) / Number.i
        Return r
    End Function
    Function cosh(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = cos(Number.i * x)
        Return r
    End Function
    Function tanh(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = (tan(Number.i * x)) / Number.i
        Return r
    End Function
    Function atanh(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = Math.log(Math.sqrt((1 + x) / (1 - x)))
        Return r
    End Function
    Function atanh(ByVal x As realnum) As realnum
        Dim r As realnum = New realnum
        r = Math.log(Math.sqrt((1 + x) / (1 - x)))
        Return r
    End Function
    Function log10(ByVal x As Number) As Number
        Dim r As Number = New Number
        r = log(x) / log(New Number(10))
        Return r
    End Function
End Module
