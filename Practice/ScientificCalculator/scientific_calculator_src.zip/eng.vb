Public Class eng
    Private Sub eng_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        calculator.trigfn.inv.Checked = False
        calculator.Select()
    End Sub
    Public Sub eng_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Location = New System.Drawing.Point(calculator.Right, calculator.Bottom - Me.Height - calculator.trigfn.Height - calculator.memoryfrm.Height)
        Me.Owner = calculator
        Me.BackColor = calculator.BackColor
    End Sub
    Private Sub eng_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        Me.Location = New System.Drawing.Point(calculator.Right, calculator.Bottom - Me.Height - calculator.trigfn.Height - calculator.memoryfrm.Height)
    End Sub
    Private Sub eng_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        calculator.Select()
    End Sub
    Private Sub sel(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click, �.Click, f.Click, G.Click, k.Click, M.Click, milli.Click, n.Click, p.Click, T.Click
        If calculator.s = 0 Then
            calculator.expression.Select()
        End If
        calculator.comment.Text = ""
    End Sub
    Private Sub engbut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles �.Click, f.Click, G.Click, k.Click, M.Click, milli.Click, n.Click, p.Click, T.Click
        calculator.Select()
        If Not calculator.s = 0 Then
            Return
        End If
        calculator.expression.Paste(sender.text)
        If calculator.trigfn.inv.Checked Then
            calculator.trigfn.inv.Checked = False
        End If
    End Sub
End Class