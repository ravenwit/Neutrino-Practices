<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class trign
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.sin = New System.Windows.Forms.Button
        Me.cos = New System.Windows.Forms.Button
        Me.tan = New System.Windows.Forms.Button
        Me.sinh = New System.Windows.Forms.Button
        Me.tanh = New System.Windows.Forms.Button
        Me.cosh = New System.Windows.Forms.Button
        Me.inv = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'sin
        '
        Me.sin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sin.ForeColor = System.Drawing.Color.Blue
        Me.sin.Location = New System.Drawing.Point(12, 30)
        Me.sin.Name = "sin"
        Me.sin.Size = New System.Drawing.Size(45, 25)
        Me.sin.TabIndex = 0
        Me.sin.Text = "sin"
        Me.sin.UseVisualStyleBackColor = True
        '
        'cos
        '
        Me.cos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cos.ForeColor = System.Drawing.Color.Blue
        Me.cos.Location = New System.Drawing.Point(59, 30)
        Me.cos.Name = "cos"
        Me.cos.Size = New System.Drawing.Size(45, 25)
        Me.cos.TabIndex = 1
        Me.cos.Text = "cos"
        Me.cos.UseVisualStyleBackColor = True
        '
        'tan
        '
        Me.tan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tan.ForeColor = System.Drawing.Color.Blue
        Me.tan.Location = New System.Drawing.Point(106, 30)
        Me.tan.Name = "tan"
        Me.tan.Size = New System.Drawing.Size(45, 25)
        Me.tan.TabIndex = 2
        Me.tan.Text = "tan"
        Me.tan.UseVisualStyleBackColor = True
        '
        'sinh
        '
        Me.sinh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sinh.ForeColor = System.Drawing.Color.Blue
        Me.sinh.Location = New System.Drawing.Point(153, 30)
        Me.sinh.Name = "sinh"
        Me.sinh.Size = New System.Drawing.Size(45, 25)
        Me.sinh.TabIndex = 3
        Me.sinh.Text = "sinh"
        Me.sinh.UseVisualStyleBackColor = True
        '
        'tanh
        '
        Me.tanh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tanh.ForeColor = System.Drawing.Color.Blue
        Me.tanh.Location = New System.Drawing.Point(247, 30)
        Me.tanh.Name = "tanh"
        Me.tanh.Size = New System.Drawing.Size(45, 25)
        Me.tanh.TabIndex = 5
        Me.tanh.Text = "tanh"
        Me.tanh.UseVisualStyleBackColor = True
        '
        'cosh
        '
        Me.cosh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cosh.ForeColor = System.Drawing.Color.Blue
        Me.cosh.Location = New System.Drawing.Point(200, 30)
        Me.cosh.Name = "cosh"
        Me.cosh.Size = New System.Drawing.Size(45, 25)
        Me.cosh.TabIndex = 4
        Me.cosh.Text = "cosh"
        Me.cosh.UseVisualStyleBackColor = True
        '
        'inv
        '
        Me.inv.AutoSize = True
        Me.inv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inv.Location = New System.Drawing.Point(248, 5)
        Me.inv.Name = "inv"
        Me.inv.Size = New System.Drawing.Size(44, 19)
        Me.inv.TabIndex = 6
        Me.inv.Text = "inv"
        Me.inv.UseVisualStyleBackColor = True
        '
        'trign
        '
        Me.AccessibleDescription = ""
        Me.AccessibleName = ""
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(302, 68)
        Me.ControlBox = False
        Me.Controls.Add(Me.inv)
        Me.Controls.Add(Me.cosh)
        Me.Controls.Add(Me.tanh)
        Me.Controls.Add(Me.sinh)
        Me.Controls.Add(Me.tan)
        Me.Controls.Add(Me.cos)
        Me.Controls.Add(Me.sin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximumSize = New System.Drawing.Size(304, 70)
        Me.MinimumSize = New System.Drawing.Size(304, 70)
        Me.Name = "trign"
        Me.ShowInTaskbar = False
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents sin As System.Windows.Forms.Button
    Friend WithEvents cos As System.Windows.Forms.Button
    Friend WithEvents tan As System.Windows.Forms.Button
    Friend WithEvents sinh As System.Windows.Forms.Button
    Friend WithEvents tanh As System.Windows.Forms.Button
    Friend WithEvents cosh As System.Windows.Forms.Button
    Friend WithEvents inv As System.Windows.Forms.CheckBox
End Class
