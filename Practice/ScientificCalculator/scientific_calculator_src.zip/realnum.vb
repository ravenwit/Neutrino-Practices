Public Class realnum
    Dim value As Double
    Dim num As Double
    Dim den As ULong
    Dim fractionvalid As Boolean
    Public Function validfr() As Boolean
        Return fractionvalid
    End Function
    Sub New()
        num = 0
        den = 1
        fractionvalid = True
    End Sub
    Sub New(ByVal x As Integer)
        value = x
        num = x
        den = 1
        fractionvalid = True
    End Sub
    Sub New(ByVal x As Double)
        value = x
        Number.findfract(value, fractionvalid, num, den)
    End Sub
    Shared Sub simplifyfraction(ByRef a As Double, ByRef b As ULong)
        Dim s As Boolean = False
        If a < 0 Then
            s = True
            a = a * -1
        End If
        Dim d As Long = Math.gcd(a, b)
        a = a / d
        If s = True Then
            a = a * -1
        End If
        b = b / d
    End Sub
    Shared Operator +(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        r.value = a.value + b.value
        If a.fractionvalid And b.fractionvalid Then
            r.den = Math.lcm(a.den, b.den)
            r.num = a.num * (r.den / a.den) + b.num * (r.den / b.den)
            simplifyfraction(r.num, r.den)
            r.fractionvalid = True
        ElseIf a.fractionvalid Or b.fractionvalid Then
            r.fractionvalid = False
        Else
            Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        End If
        Return r
    End Operator
    Shared Operator -(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        r.value = a.value - b.value
        If a.fractionvalid And b.fractionvalid Then
            r.den = Math.lcm(a.den, b.den)
            r.num = a.num * r.den / a.den - b.num * r.den / b.den
            simplifyfraction(r.num, r.den)
            r.fractionvalid = True
        ElseIf a.fractionvalid Or b.fractionvalid Then
            r.fractionvalid = False
        Else
            Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        End If
        Return r
    End Operator
    Shared Operator -(ByVal a As realnum) As realnum
        Dim r As realnum = a
        r.value = -a.value
        r.num = -a.num
        Return r
    End Operator
    Shared Operator *(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        r.value = a.value * b.value
        If a.fractionvalid And b.fractionvalid Then
            r.den = a.den * b.den
            r.num = a.num * b.num
            simplifyfraction(r.num, r.den)
            r.fractionvalid = True
        ElseIf a.fractionvalid Or b.fractionvalid Then
            r.fractionvalid = False
        Else
            Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        End If
        Return r
    End Operator
    Shared Operator /(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        Dim t As realnum = New realnum
        r.value = a.value / b.value
        If a.fractionvalid And b.fractionvalid Then
            r.den = a.den
            r.num = b.den
            simplifyfraction(r.num, r.den)
            t.den = System.Math.Abs(b.num)
            t.num = a.num
            If b.num < 0 Then
                t.num = -t.num
            End If
            simplifyfraction(t.num, t.den)
            r.den = r.den * t.den
            r.num = r.num * t.num
            r.fractionvalid = True
            If b = 0 Or r.den = 0 Then
                r.fractionvalid = False
                Return r
            End If
            simplifyfraction(r.num, r.den)
        ElseIf a.fractionvalid Or b.fractionvalid Then
            r.fractionvalid = False
        Else
            Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        End If
        Return r
    End Operator
    Shared Operator ^(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        r.value = a.value ^ b.value
        If a.fractionvalid And b.fractionvalid Then
            If b.den = 1 Then
                r.fractionvalid = True
                r.num = a.num ^ b.num
                r.den = a.den ^ b.num
                Return r
            End If
        End If
        Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        Return r
    End Operator
    Shared Operator Mod(ByVal a As realnum, ByVal b As realnum) As realnum
        Dim r As realnum = New realnum
        r.value = a.value Mod b.value
        Number.findfract(r.value, r.fractionvalid, r.num, r.den)
        Return r
    End Operator
    Shared Operator =(ByVal a As realnum, ByVal b As Double) As Boolean
        If a.value = b Then
            Return True
        End If
        Return False
    End Operator
    Shared Operator <>(ByVal a As realnum, ByVal b As Double) As Boolean
        If Not a.value = b Then
            Return True
        End If
        Return False
    End Operator
    Shared Operator <(ByVal a As realnum, ByVal b As Double) As Boolean
        If a.value < b Then
            Return True
        End If
        Return False
    End Operator
    Shared Operator >(ByVal a As realnum, ByVal b As Double) As Boolean
        If a.value > b Then
            Return True
        End If
        Return False
    End Operator
    Shared Widening Operator CType(ByVal x As Double) As realnum
        Dim r As realnum = New realnum(x)
        Return r
    End Operator
    Shared Widening Operator CType(ByVal x As realnum) As Double
        Return x.value
    End Operator
    Shared Narrowing Operator CType(ByVal x As realnum) As String
        Dim r As String
        If x.fractionvalid = False Then
            r = Convert.ToString(x.value)
            Return r
        End If
        If calculator.FractionToolStripMenuItem.Checked Then
            r = "(" + Convert.ToString(x.num) + "/" + Convert.ToString(x.den) + ")"
            Return r
        Else
            r = Convert.ToString(x.value)
            Return r
        End If
    End Operator
    Function fw() As String
        Dim r As String
        r = Convert.ToString(value) + "|" + Convert.ToString(num) + "|" + Convert.ToString(den) + "|" + Convert.ToString(fractionvalid) + "|"
        Return r
    End Function
    sub fr(ByRef s As String)
        Dim b(4) As String
        b = s.Split("|"c)
        value = Convert.ToDouble(b(0))
        num = b(1)
        den = b(2)
        fractionvalid = b(3)
    End Sub
    Sub log()
        value = System.Math.Log(value)
        Number.findfract(value, fractionvalid, num, den)
    End Sub
End Class
'pending:.6,file io,ampl in deg,fraction
